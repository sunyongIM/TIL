package mc.sn.test.service;

import mc.sn.test.vo.LonginVO;

public interface LonginService {
	public LonginVO loginTest(String id, String password); 
}
