package mc.sn.test.dao;

import mc.sn.test.vo.LonginVO;

public interface LonginDao {
	public LonginVO selectTest(LonginVO longinvo); 
}
