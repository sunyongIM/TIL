package mc.sn.test;


public class ServletInitializer extends AiFwTestApplication {


}
