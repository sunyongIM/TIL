/**
 * 
 */
$(function(){
	$("#login_btn").click(function(){
		var id = $("#id").val();
		var pw = $("#pw").val();
		alert(id+":"+pw);
	})
});